<?php

namespace Picqer\Barcode\Exceptions;

class UnknownColorException extends BarcodeException {}
