<?php

namespace Picqer\Barcode\Exceptions;

class InvalidOptionException extends BarcodeException {}
